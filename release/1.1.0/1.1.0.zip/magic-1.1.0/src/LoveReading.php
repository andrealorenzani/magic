<?php
declare(strict_types=1);

namespace Magic;

use Magic\Bio\Biorhythm;
use Magic\Bio\Synchrony;
use Magic\Earth\Geography;
use Magic\Love\Common;
use Magic\Love\Harmony;
use Magic\Love\NameAffinity;
use Magic\Love\Synastry;
use Magic\Sky\Today;
use Magic\Tarot\Reading;

/** Pure builder of the Love view-model. */
final class LoveReading
{
    /**
     * @param array<string,mixed> $a person shape (see Request::parseLove)
     * @param array<string,mixed> $b person shape; date/time/place may be null. Optional keys: `label` (shown instead of
     *        the name, used for details that are not displayed) and `anonymous` (no name was shared)
     * @param ?list<array{number:int, reversed:bool}> $tarotSlots a validated shared spread, used instead of the deterministic one
     * @param string $dayBasis where the reading day came from: 'utc' | 'current_position' | 'on'
     * @return array<string,mixed>
     */
    public static function build(array $a, array $b, string $today, ?array $tarotSlots = null, string $dayBasis = 'utc'): array
    {
        $hidden = isset($b['label']);
        $shownB = $hidden ? (string) $b['label'] : (string) $b['name'];
        $anonymous = $hidden && !empty($b['anonymous']);
        $chartA = self::chart($a);
        $chartB = self::chart($b);
        $notes = [];
        if ($b['date'] === null) {
            $notes[] = 'Add the loved person\'s birth date to compare signs and biorhythms.';
        }
        $bio = null;
        if ($a['date'] !== null && $b['date'] !== null) {
            $bio = Synchrony::pair(self::day($a['date']), self::day($b['date']), Biorhythm::dayOf($today));
        }
        $common = ($chartA !== null && $chartB !== null) ? Common::between($chartA, $chartB) : null;
        $seed = strtolower(trim($a['name'])) . '|' . strtolower(trim($b['name'])) . '|' . self::ymd($a['date']) . '|' . self::ymd($b['date']);
        $tarot = $tarotSlots !== null ? Reading::fromSlots($tarotSlots) : Reading::spread($seed, $today);
        return [
            'names' => ['a' => $a['name'], 'b' => $shownB],
            'hidden' => $hidden,
            'affinity' => $anonymous ? NameAffinity::fromCounts([]) : NameAffinity::compute($a['name'], $b['name']),
            'fights' => $anonymous
                ? NameAffinity::fromCounts([], NameAffinity::FIGHT_LETTERS)
                : NameAffinity::compute($a['name'], $b['name'], NameAffinity::FIGHT_LETTERS),
            'harmony' => Harmony::compute($bio, $chartA, $chartB, $tarot),
            'charts' => ['a' => $chartA, 'b' => $chartB],
            'common' => $common,
            'bio' => $bio,
            'tarot' => $tarot,
            'tarotShared' => $tarotSlots !== null,
            'today' => $today,
            'dayBasis' => $dayBasis,
            'dayZone' => $dayBasis === 'current_position' ? ($a['now']['tz'] ?? null) : null,
            'sky' => Today::for($today, array_filter(['a' => $chartA['sun'] ?? null, 'b' => $chartB['sun'] ?? null])),
            'synastry' => self::synastry($a, $b),
            'geo' => Geography::forLove($a, ['name' => $shownB] + $b, $today),
            'notes' => $notes,
        ];
    }

    /** @param array<string,mixed> $a @param array<string,mixed> $b @return array<string,mixed> */
    private static function synastry(array $a, array $b): array
    {
        if ($a['date'] === null || $b['date'] === null) {
            return ['rows' => [], 'total' => 0, 'counts' => ['harmonious' => 0, 'tense' => 0, 'neutral' => 0], 'approx' => true, 'available' => false];
        }
        return Synastry::between(self::longitudes($a), self::longitudes($b));
    }

    /** @param array<string,mixed> $p @return array<string,float> */
    private static function longitudes(array $p): array
    {
        $d = $p['date'];
        $full = $p['time'] !== null && $p['place'] !== null;
        return Chart::longitudes(
            $d['year'], $d['month'], $d['day'],
            $full ? $p['time']['hour'] : null, $full ? $p['time']['minute'] : null,
            $full ? $p['place']['lat'] : null, $full ? $p['place']['lon'] : null, $full ? $p['place']['tz'] : null
        );
    }

    /** @param array<string,mixed> $p @return ?array<string,mixed> */
    private static function chart(array $p): ?array
    {
        if ($p['date'] === null) {
            return null;
        }
        $d = $p['date'];
        $full = $p['time'] !== null && $p['place'] !== null;
        return Chart::partial(
            $d['year'], $d['month'], $d['day'],
            $full ? $p['time']['hour'] : null, $full ? $p['time']['minute'] : null,
            $full ? $p['place']['lat'] : null, $full ? $p['place']['lon'] : null, $full ? $p['place']['tz'] : null
        );
    }

    /** @param array{year:int,month:int,day:int} $d */
    private static function day(array $d): int
    {
        return Biorhythm::dayNumber($d['year'], $d['month'], $d['day']);
    }

    private static function ymd(?array $d): string
    {
        return $d === null ? '' : sprintf('%04d-%02d-%02d', $d['year'], $d['month'], $d['day']);
    }
}
